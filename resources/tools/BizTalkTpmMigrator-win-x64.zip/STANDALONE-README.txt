BizTalk EDI Agreement Migrator
==============================

Input
-----
An XML file produced by BTSTask ExportParties.

Supported artifacts
-------------------
- Integration Account partners
- X12 agreements
- EDIFACT agreements
- AS2 agreements

Generate JSON
-------------
BizTalkTpmMigrator.exe export --input C:\exports\ExportParties.xml

The default output directory is "integration-account-artifacts" beside the
input XML. Use --output to select another directory.

Deploy to an Integration Account
--------------------------------
1. Install Azure CLI.
2. Run: az login
3. Run:

BizTalkTpmMigrator.exe deploy ^
  --input C:\exports\ExportParties.xml ^
  --output C:\exports\integration-account-artifacts ^
  --subscription <subscription-id> ^
  --resource-group <resource-group> ^
  --integration-account <integration-account-name>

The tool validates and generates JSON first, writes deployment-plan.json,
deploys partners before agreements, skips unchanged resources, and protects
updates with ETags.

During deployment, X12 schema overrides are matched to schemas already deployed
in the Integration Account. If duplicate schema documents have different
resource names, the first API result is selected. If no schema matches, the
reference is ignored and a warning asks you to deploy the schema first and run
the migration again.

Help
----
BizTalkTpmMigrator.exe --help
